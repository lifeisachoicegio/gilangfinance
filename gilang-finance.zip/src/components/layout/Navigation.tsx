import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  LayoutDashboard, 
  ArrowLeftRight, 
  BarChart3, 
  Wallet, 
  Target, 
  Settings, 
  Bot,
  LogOut,
  Menu,
  X,
  CreditCard
} from 'lucide-react';
import { cn } from '@/lib/utils';
import { Button } from '@/components/ui/button';
import { useAuthStore } from '@/store/useAuthStore';

interface NavItemProps {
  icon: any;
  label: string;
  active?: boolean;
  onClick: () => void;
  isCollapsed?: boolean;
  key?: string;
}

const NavItem = ({ icon: Icon, label, active, onClick, isCollapsed }: NavItemProps) => (
  <button
    onClick={onClick}
    className={cn(
      "w-full flex items-center gap-3 px-4 py-2.5 rounded-xl transition-all duration-300 group text-left",
      active 
        ? "bg-indigo-600 text-white font-medium" 
        : "text-slate-500 hover:bg-slate-50 hover:text-slate-900"
    )}
  >
    <Icon className={cn("w-5 h-5", active ? "text-white" : "group-hover:scale-110 transition-transform")} />
    {!isCollapsed && <span className="text-sm">{label}</span>}
  </button>
);

export const Navigation = ({ activeTab, setActiveTab }: { activeTab: string, setActiveTab: (tab: string) => void }) => {
  const [isCollapsed, setIsCollapsed] = useState(false);
  const { logout, profile } = useAuthStore();

  const navItems = [
    { id: 'dashboard', icon: LayoutDashboard, label: 'Dashboard' },
    { id: 'transactions', icon: ArrowLeftRight, label: 'Transaksi' },
    { id: 'analytics', icon: BarChart3, label: 'Analisis' },
    { id: 'budget', icon: Wallet, label: 'Anggaran' },
    { id: 'goals', icon: Target, label: 'Tabungan' },
    { id: 'banks', icon: CreditCard, label: 'Bank Terhubung' },
    { id: 'ai', icon: Bot, label: 'Asisten AI' },
  ];

  return (
    <aside 
      className={cn(
        "h-screen bg-white border-r border-slate-200 flex flex-col transition-all duration-500 z-50",
        isCollapsed ? "w-20" : "w-64"
      )}
    >
      <div className="p-6 flex items-center justify-between">
        {!isCollapsed && (
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="flex items-center gap-2"
          >
            <div className="w-8 h-8 bg-indigo-600 rounded-lg flex items-center justify-center">
               <div className="w-4 h-4 bg-white rounded-full"></div>
            </div>
            <span className="font-bold text-xl tracking-tight text-slate-900">Gilang Finance</span>
          </motion.div>
        )}
        <Button 
          variant="ghost" 
          size="icon" 
          onClick={() => setIsCollapsed(!isCollapsed)}
          className="hover:bg-slate-50"
        >
          {isCollapsed ? <Menu className="w-5 h-5" /> : <X className="w-5 h-5 text-slate-400" />}
        </Button>
      </div>

      <nav className="flex-1 px-4 space-y-1 mt-4">
        {navItems.map((item) => (
          <NavItem 
            key={item.id}
            icon={item.icon}
            label={item.label}
            active={activeTab === item.id}
            onClick={() => setActiveTab(item.id)}
            isCollapsed={isCollapsed}
          />
        ))}
      </nav>

      {!isCollapsed && (
        <div className="px-4 mb-4">
          <div className="bg-slate-900 rounded-2xl p-4 text-white">
            <p className="text-[10px] text-slate-400 mb-1 font-medium uppercase tracking-wider">Tantangan Menabung</p>
            <p className="text-xs mb-3 font-medium">Simpan Rp 2.500.000 lagi untuk target!</p>
            <div className="w-full bg-slate-700 h-1 rounded-full">
              <div className="bg-indigo-500 h-full rounded-full" style={{ width: '65%' }}></div>
            </div>
          </div>
        </div>
      )}

      <div className="p-4 border-t border-slate-100 space-y-2">
        <button className="flex items-center gap-3 px-4 py-2 w-full text-slate-500 hover:text-slate-900 transition-colors">
          <Settings className="w-5 h-5" />
          {!isCollapsed && <span className="text-sm font-medium">Pengaturan</span>}
        </button>
        <button 
          onClick={logout}
          className="flex items-center gap-3 px-4 py-2 w-full text-rose-500 hover:text-rose-600 transition-colors"
        >
          <LogOut className="w-5 h-5" />
          {!isCollapsed && <span className="text-sm font-medium">Keluar</span>}
        </button>
        
        {!isCollapsed && profile && (
          <div className="flex items-center gap-3 px-2 py-2 mt-2">
            <div className="w-10 h-10 rounded-full bg-slate-200 border border-white overflow-hidden shadow-sm">
               {profile.photoURL ? <img src={profile.photoURL} alt="User" /> : null}
            </div>
            <div className="flex-1 min-w-0">
              <p className="text-sm font-bold text-slate-900 truncate">{profile.displayName || 'Sahabat Gilang'}</p>
              <p className="text-xs text-slate-400 truncate">Akun Pro</p>
            </div>
          </div>
        )}
      </div>
    </aside>
  );
};

