import { GoogleGenAI } from "@google/genai";

const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY as string });

export const getFinancialAdvice = async (transactions: any[], userProfile: any) => {
  try {
    const prompt = `
      You are Gilang Finance AI, a premium personal finance coach. 
      Analyze the following transactions and user profile to provide 3 actionable, personalized financial tips in Indonesian.
      User Profile: ${JSON.stringify(userProfile)}
      Recent Transactions: ${JSON.stringify(transactions.slice(0, 10))}
      
      Return the response in JSON format:
      {
        "score": number (0-100),
        "tips": [
          { "type": "warning" | "opportunity" | "good", "title": string, "message": string }
        ],
        "prediction": string (short prediction for next month)
      }
    `;

    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: prompt,
      config: {
        responseMimeType: "application/json"
      }
    });

    return JSON.parse(response.text || '{}');
  } catch (error) {
    console.error("AI Insight Error:", error);
    return null;
  }
};

export const chatWithArtha = async (history: { role: string, parts: any[] }[], message: string) => {
  const chat = ai.chats.create({
    model: "gemini-3-flash-preview",
    config: {
      systemInstruction: "Anda adalah Gilang Finance AI, asisten keuangan pribadi yang membantu dan canggih. Anda membantu pengguna mengelola anggaran, melacak pengeluaran, dan merencanakan target tabungan. Jaga nada bicara Anda tetap profesional, menyemangati, dan jelas. Selalu balas dalam bahasa Indonesia. Jika ditanya tentang keamanan bank, jelaskan bahwa kami menggunakan enkripsi ujung-ke-ujung dan tidak menyimpan kredensial mentah."
    }
  });

  const response = await chat.sendMessage({ message });
  return response.text;
};
