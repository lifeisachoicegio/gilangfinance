import { initializeApp } from 'firebase/app';
import { getAuth } from 'firebase/auth';
import { getFirestore, doc, getDocFromServer } from 'firebase/firestore';
import firebaseConfig from '../../firebase-applet-config.json';

const app = initializeApp(firebaseConfig);
export const auth = getAuth(app);
export const db = getFirestore(app, (firebaseConfig as any).firestoreDatabaseId);

// Critical: Validate connection to Firestore
async function testConnection() {
  try {
    await getDocFromServer(doc(db, 'test', 'connection'));
  } catch (error: any) {
    if (error?.message?.includes('the client is offline')) {
      console.error("Please check your Firebase configuration.");
    } else if (error?.code === 'permission-denied' || error?.message?.includes('permission-denied') || error?.message?.includes('insufficient permissions')) {
      // This is actually "success" in terms of connectivity if we get a permission error
      console.log("Connected to Firebase (Auth pending)");
    } else {
      console.error("Firebase connection test failed:", error);
    }
  }
}

testConnection();
