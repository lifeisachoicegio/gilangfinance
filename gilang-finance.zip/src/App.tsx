/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useEffect, useState } from 'react';
import { useAuthStore } from './store/useAuthStore';
import { LandingPage } from './pages/Landing';
import { Dashboard } from './pages/Dashboard';
import { TransactionsPage } from './pages/TransactionsPage';
import { ConnectedBanks } from './pages/ConnectedBanks';
import { Analytics } from './pages/Analytics';
import { AIAssistant } from './pages/AIAssistant';
import { BudgetPage } from './pages/BudgetPage';
import { GoalsPage } from './pages/GoalsPage';
import { Navigation } from './components/layout/Navigation';
import { Toaster } from './components/ui/sonner';
import { Skeleton } from './components/ui/skeleton';
import { doc, getDocFromServer } from 'firebase/firestore';
import { db } from './lib/firebase';
import { toast } from 'sonner';

export default function App() {
  const { user, initialized, loading, initialize } = useAuthStore();
  const [activeTab, setActiveTab] = useState('dashboard');

  useEffect(() => {
    initialize();
    
    // Test Firebase connection
    async function testConnection() {
      try {
        await getDocFromServer(doc(db, 'test', 'connection'));
      } catch (error) {
        if(error instanceof Error && error.message.includes('the client is offline')) {
          console.error("Please check your Firebase configuration.");
          toast.error("Firebase connection error. Please check your configuration.");
        }
      }
    }
    testConnection();
  }, []);

  if (!initialized || (loading && !user)) {
    return (
      <div className="h-screen flex items-center justify-center bg-slate-50">
        <div className="space-y-4 text-center">
           <div className="w-16 h-16 bg-indigo-600 rounded-2xl animate-pulse mx-auto flex items-center justify-center">
             <div className="w-8 h-8 bg-white rounded-full"></div>
           </div>
           <p className="text-slate-400 animate-pulse font-bold tracking-widest uppercase text-[10px]">Gilang Finance sedang memuat</p>
        </div>
      </div>
    );
  }

  if (!user) {
    return <LandingPage />;
  }

  const renderContent = () => {
    switch (activeTab) {
      case 'dashboard': return <Dashboard setActiveTab={setActiveTab} />;
      case 'transactions': return <TransactionsPage />;
      case 'analytics': return <Analytics />;
      case 'budget': return <BudgetPage />;
      case 'goals': return <GoalsPage />;
      case 'banks': return <ConnectedBanks />;
      case 'ai': return <AIAssistant />;
      default: return <Dashboard setActiveTab={setActiveTab} />;
    }
  };

  return (
    <div className="flex h-screen bg-background text-foreground overflow-hidden">
      <Navigation activeTab={activeTab} setActiveTab={setActiveTab} />
      <main className="flex-1 h-screen overflow-y-auto">
        {renderContent()}
      </main>
      <Toaster />
    </div>
  );
}
