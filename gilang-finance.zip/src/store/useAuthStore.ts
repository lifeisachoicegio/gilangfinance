import { create } from 'zustand';
import { User } from 'firebase/auth';
import { auth, db } from '../lib/firebase';
import { onAuthStateChanged, signOut } from 'firebase/auth';
import { doc, getDoc, setDoc, onSnapshot } from 'firebase/firestore';

interface UserProfile {
  uid: string;
  email: string | null;
  displayName: string | null;
  photoURL: string | null;
  financialHealthScore: number;
  totalBalance: number;
  currency: string;
}

interface AuthState {
  user: User | null;
  profile: UserProfile | null;
  loading: boolean;
  initialized: boolean;
  setUser: (user: User | null) => void;
  setProfile: (profile: UserProfile | null) => void;
  initialize: () => void;
  logout: () => Promise<void>;
}

export const useAuthStore = create<AuthState>((set) => ({
  user: null,
  profile: null,
  loading: true,
  initialized: false,
  setUser: (user) => set({ user }),
  setProfile: (profile) => set({ profile }),
  initialize: () => {
    onAuthStateChanged(auth, async (user) => {
      if (user) {
        set({ user, loading: true });
        // Fetch or create profile
        const profileRef = doc(db, 'users', user.uid);
        const profileSnap = await getDoc(profileRef);

        if (profileSnap.exists()) {
          set({ profile: profileSnap.data() as UserProfile, loading: false });
        } else {
          const newProfile: UserProfile = {
            uid: user.uid,
            email: user.email,
            displayName: user.displayName,
            photoURL: user.photoURL,
            financialHealthScore: 75,
            totalBalance: 0,
            currency: 'USD',
          };
          await setDoc(profileRef, newProfile);
          set({ profile: newProfile, loading: false });
        }

        // Real-time profile updates
        onSnapshot(profileRef, (snap) => {
          if (snap.exists()) {
            set({ profile: snap.data() as UserProfile });
          }
        });
      } else {
        set({ user: null, profile: null, loading: false });
      }
      set({ initialized: true });
    });
  },
  logout: async () => {
    await signOut(auth);
    set({ user: null, profile: null });
  },
}));
