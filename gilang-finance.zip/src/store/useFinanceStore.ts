import { create } from 'zustand';
import { 
  collection, 
  onSnapshot, 
  query, 
  where, 
  orderBy, 
  addDoc, 
  serverTimestamp,
  doc,
  updateDoc,
  deleteDoc,
  Timestamp
} from 'firebase/firestore';
import { db, auth } from '../lib/firebase';

export enum OperationType {
  CREATE = 'create',
  UPDATE = 'update',
  DELETE = 'delete',
  LIST = 'list',
  GET = 'get',
  WRITE = 'write',
}

interface FirestoreErrorInfo {
  error: string;
  operationType: OperationType;
  path: string | null;
  authInfo: {
    userId?: string | null;
    email?: string | null;
    emailVerified?: boolean | null;
    isAnonymous?: boolean | null;
    tenantId?: string | null;
    providerInfo?: {
      providerId?: string | null;
      email?: string | null;
    }[];
  }
}

function handleFirestoreError(error: unknown, operationType: OperationType, path: string | null) {
  const errInfo: FirestoreErrorInfo = {
    error: error instanceof Error ? error.message : String(error),
    authInfo: {
      userId: auth.currentUser?.uid,
      email: auth.currentUser?.email,
      emailVerified: auth.currentUser?.emailVerified,
      isAnonymous: auth.currentUser?.isAnonymous,
      tenantId: auth.currentUser?.tenantId,
      providerInfo: auth.currentUser?.providerData?.map(provider => ({
        providerId: provider.providerId,
        email: provider.email,
      })) || []
    },
    operationType,
    path
  }
  console.error('Firestore Error: ', JSON.stringify(errInfo));
  throw new Error(JSON.stringify(errInfo));
}

export interface ArthaTransaction {
  id: string;
  userId: string;
  bankAccountId: string;
  amount: number;
  currency: string;
  date: string;
  description: string;
  category: string;
  type: 'income' | 'expense';
  merchantName?: string;
  isSubscription?: boolean;
  manual?: boolean;
  createdAt: any;
}

export interface Category {
  id: string;
  userId: string;
  name: string;
  color: string;
  createdAt: any;
}

interface FinanceState {
  transactions: ArthaTransaction[];
  categories: Category[];
  loading: boolean;
  fetchTransactions: (userId: string) => () => void;
  fetchCategories: (userId: string) => () => void;
  addTransaction: (userId: string, data: Partial<ArthaTransaction>) => Promise<void>;
  addCategory: (userId: string, name: string, color: string) => Promise<void>;
  deleteCategory: (categoryId: string) => Promise<void>;
}

export const useFinanceStore = create<FinanceState>((set) => ({
  transactions: [],
  categories: [],
  loading: false,
  fetchTransactions: (userId) => {
    set({ loading: true });
    const q = query(
      collection(db, 'transactions'),
      where('userId', '==', userId),
      orderBy('date', 'desc')
    );

    return onSnapshot(q, (snap) => {
      const txs = snap.docs.map(d => ({ id: d.id, ...d.data() } as ArthaTransaction));
      set({ transactions: txs, loading: false });
    }, (error) => {
      handleFirestoreError(error, OperationType.LIST, 'transactions');
    });
  },
  fetchCategories: (userId) => {
    const q = query(
      collection(db, 'categories'),
      where('userId', '==', userId),
      orderBy('createdAt', 'asc')
    );

    return onSnapshot(q, (snap) => {
      const cats = snap.docs.map(d => ({ id: d.id, ...d.data() } as Category));
      set({ categories: cats });
    }, (error) => {
      handleFirestoreError(error, OperationType.LIST, 'categories');
    });
  },
  addTransaction: async (userId, data) => {
    try {
      await addDoc(collection(db, 'transactions'), {
        ...data,
        userId,
        createdAt: serverTimestamp(),
      });
    } catch (error) {
      handleFirestoreError(error, OperationType.CREATE, 'transactions');
    }
  },
  addCategory: async (userId, name, color) => {
    try {
      await addDoc(collection(db, 'categories'), {
        userId,
        name,
        color,
        createdAt: serverTimestamp(),
      });
    } catch (error) {
      handleFirestoreError(error, OperationType.CREATE, 'categories');
    }
  },
  deleteCategory: async (categoryId) => {
    try {
      await deleteDoc(doc(db, 'categories', categoryId));
    } catch (error) {
      handleFirestoreError(error, OperationType.DELETE, `categories/${categoryId}`);
    }
  },
}));
