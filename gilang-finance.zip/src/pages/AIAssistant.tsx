import React, { useState } from 'react';
import { Card } from '../components/ui/card';
import { Bot, Sparkles } from 'lucide-react';
import { chatWithArtha } from '../services/gemini';
import { ScrollArea } from '../components/ui/scroll-area';
import { Input } from '../components/ui/input';
import { Button } from '../components/ui/button';

export const AIAssistant = () => {
  const [messages, setMessages] = useState<{ role: 'user' | 'ai', content: string }[]>([
    { role: 'ai', content: "Halo! Saya Gilang AI, asisten finansial cerdas Anda. Apa yang ingin Anda tanyakan hari ini?" }
  ]);
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);

  const sendMessage = async () => {
    if (!input.trim()) return;
    const userMsg = input;
    setInput('');
    setMessages(prev => [...prev, { role: 'user', content: userMsg }]);
    setLoading(true);

    try {
      const response = await chatWithArtha([], userMsg);
      setMessages(prev => [...prev, { role: 'ai', content: response || "Saya sedang mengalami gangguan sedikit." }]);
    } catch (e) {
      setMessages(prev => [...prev, { role: 'ai', content: "Maaf, terjadi kesalahan pada sistem kami." }]);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="h-screen flex flex-col p-8 artha-gradient">
      <div className="mb-8">
        <h1 className="text-2xl font-bold flex items-center gap-2 text-slate-900">
          <Bot className="text-indigo-600" /> Strategi Keuangan AI
        </h1>
        <p className="text-slate-500 text-sm">Saran finansial ahli didukung oleh AI.</p>
      </div>

      <Card className="flex-1 bg-white rounded-3xl border-slate-100 flex flex-col overflow-hidden shadow-sm">
        <ScrollArea className="flex-1 p-6">
          <div className="space-y-6">
            {messages.map((m, i) => (
              <div key={i} className={`flex ${m.role === 'user' ? 'justify-end' : 'justify-start'}`}>
                <div className={`max-w-[80%] p-4 rounded-2xl ${m.role === 'user' ? 'bg-indigo-600 text-white font-medium shadow-lg shadow-indigo-100' : 'bg-slate-50 text-slate-900 border border-slate-100'}`}>
                   {m.content}
                </div>
              </div>
            ))}
            {loading && (
              <div className="flex justify-start">
                 <div className="bg-slate-50 p-4 rounded-2xl animate-pulse flex items-center gap-2 text-slate-400">
                    <Sparkles className="w-4 h-4 text-indigo-400 animate-spin" />
                    Sedang berpikir...
                 </div>
              </div>
            )}
          </div>
        </ScrollArea>
        <div className="p-4 bg-slate-50/50 border-t border-slate-100 flex gap-3">
          <Input 
            placeholder="Tanyakan tentang anggaran, tabungan, atau saran investasi..." 
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && sendMessage()}
            className="flex-1 h-12 rounded-xl bg-white border-slate-200"
          />
          <Button onClick={sendMessage} className="bg-indigo-600 text-white hover:bg-indigo-700 rounded-xl px-6 h-12">
            Kirim
          </Button>
        </div>
      </Card>
    </div>
  );
};
