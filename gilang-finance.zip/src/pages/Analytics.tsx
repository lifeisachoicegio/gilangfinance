import React, { useState } from 'react';
import { Card, CardHeader, CardTitle, CardContent } from '../components/ui/card';
import { BarChart3, Calendar as CalendarIcon } from 'lucide-react';
import { cn } from '../lib/utils';

export const Analytics = () => {
  const [selectedDate, setSelectedDate] = useState<Date | undefined>(new Date());
  
  return (
    <div className="p-8 space-y-8 animate-in fade-in duration-700">
      <header>
        <h1 className="text-2xl font-bold tracking-tight text-slate-900">Analisis Finansial</h1>
        <p className="text-slate-500 text-sm">Wawasan mendalam dan perkiraan kekayaan Anda.</p>
      </header>
      
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="lg:col-span-2 space-y-8">
          <Card className="artha-card p-6">
            <h3 className="font-bold text-slate-900 mb-6">Pola Arus Kas</h3>
             <div className="h-[300px] flex items-center justify-center bg-slate-50 rounded-2xl border border-dashed border-slate-200">
                <div className="text-center space-y-2">
                   <BarChart3 className="w-8 h-8 text-indigo-400 mx-auto" />
                   <p className="text-sm font-medium text-slate-600">Mengumpulkan data untuk pola pengeluaran...</p>
                   <p className="text-xs text-slate-400">Biasanya membutuhkan 14-30 hari riwayat transaksi.</p>
                </div>
             </div>
          </Card>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
             <Card className="artha-card p-6 flex flex-col justify-between">
                <div>
                   <h3 className="font-bold text-slate-900">Target Kekayaan</h3>
                   <p className="text-xs text-slate-500">Target: Rp 1.500.000.000 pada Des 2026</p>
                </div>
                <div className="mt-8 space-y-2">
                   <div className="flex justify-between text-xs font-bold">
                      <span>Progres</span>
                      <span className="text-indigo-600">42%</span>
                   </div>
                   <div className="w-full bg-slate-100 h-2 rounded-full overflow-hidden">
                      <div className="h-full bg-indigo-600" style={{ width: '42%' }} />
                   </div>
                </div>
             </Card>
             <Card className="artha-card p-6 flex flex-col justify-between">
                <div>
                   <h3 className="font-bold text-slate-900">Tingkat Menabung</h3>
                   <p className="text-xs text-slate-500">Rata-rata dalam 3 bulan terakhir</p>
                </div>
                <div className="mt-8 flex items-baseline gap-2">
                   <span className="text-3xl font-bold text-emerald-600">18,4%</span>
                   <span className="text-xs text-slate-400">Rekomendasi: 20%</span>
                </div>
             </Card>
          </div>
        </div>

        <Card className="artha-card overflow-hidden">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-bold flex items-center gap-2">
              <CalendarIcon className="w-4 h-4 text-indigo-600" /> Kalender Tagihan
            </CardTitle>
          </CardHeader>
          <CardContent>
             <div className="p-1 border rounded-2xl bg-slate-50/50 mb-6">
                <div className="flex justify-center flex-col items-center p-4">
                   <p className="text-xs font-bold text-slate-400 uppercase mb-4">Mei 2026</p>
                   <div className="grid grid-cols-7 gap-1 w-full text-center text-[10px] font-bold text-slate-400 mb-2">
                      <span>M</span><span>S</span><span>S</span><span>R</span><span>K</span><span>J</span><span>S</span>
                   </div>
                   <div className="grid grid-cols-7 gap-1 w-full">
                      {Array.from({ length: 31 }).map((_, i) => (
                        <div 
                          key={i} 
                          className={cn(
                            "aspect-square flex items-center justify-center text-xs rounded-lg transition-colors relative",
                            i + 1 === 12 || i + 1 === 15 || i + 1 === 20 ? "bg-indigo-600 text-white font-bold" : "hover:bg-white",
                            i + 1 === new Date().getDate() ? "border border-indigo-400" : ""
                          )}
                        >
                          {i + 1}
                          {(i + 1 === 12 || i + 1 === 15 || i + 1 === 20) && (
                            <span className="absolute -top-1 -right-1 w-2 h-2 bg-rose-500 rounded-full border-2 border-white" />
                          )}
                        </div>
                      ))}
                   </div>
                </div>
             </div>

             <div className="space-y-4">
                <h4 className="text-[10px] font-bold text-slate-400 uppercase tracking-widest px-2">Tagihan Akan Datang</h4>
                <div className="space-y-2 px-2 pb-2">
                   {[
                     { name: 'Netflix', due: '12 Mei', amt: 'Rp 186.000' },
                     { name: 'Sewa Kos', due: '15 Mei', amt: 'Rp 2.500.000' },
                     { name: 'Listrik', due: '20 Mei', amt: 'Rp 450.000' },
                   ].map((bill, i) => (
                     <div key={i} className="flex items-center justify-between py-1 group cursor-pointer">
                        <div className="flex items-center gap-3">
                           <div className="w-1.5 h-1.5 rounded-full bg-indigo-600" />
                           <span className="text-xs font-medium text-slate-600 group-hover:text-slate-900">{bill.name}</span>
                        </div>
                        <span className="text-xs font-bold text-slate-900">{bill.amt}</span>
                     </div>
                   ))}
                </div>
             </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};
