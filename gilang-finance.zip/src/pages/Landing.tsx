import React from 'react';
import { motion } from 'motion/react';
import { 
  ArrowRight, 
  Shield, 
  Zap, 
  BarChart, 
  Smartphone, 
  Lock,
  Sparkles,
  Globe,
  PieChart,
  ChevronRight
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { 
  signInWithPopup, 
  GoogleAuthProvider 
} from 'firebase/auth';
import { auth } from '@/lib/firebase';
import { useAuthStore } from '@/store/useAuthStore';

export const LandingPage = () => {
  const { setUser } = useAuthStore();

  const loginWithGoogle = async () => {
    try {
      const provider = new GoogleAuthProvider();
      const result = await signInWithPopup(auth, provider);
      setUser(result.user);
    } catch (error) {
      console.error("Login Error:", error);
    }
  };

  const features = [
    { 
      icon: Zap, 
      title: "Sinkronisasi Real-time", 
      desc: "Hubungkan akun bank Anda dengan aman dan pantau transaksi Anda secara instan." 
    },
    { 
      icon: Sparkles, 
      title: "Strategi AI", 
      desc: "Asisten GenAI menganalisis pola pengeluaran Anda untuk memberikan rekomendasi menabung yang cerdas." 
    },
    { 
      icon: Shield, 
      title: "Keamanan Standar Bank", 
      desc: "Kami menggunakan enkripsi AES-256 dan autentikasi multi-faktor untuk menjaga data Anda tetap aman." 
    },
  ];

  return (
    <div className="min-h-screen bg-slate-50 text-slate-900 selection:bg-indigo-100 selection:text-indigo-900 overflow-x-hidden">
      {/* Background elements */}
      <div className="fixed inset-0 pointer-events-none">
        <div className="absolute top-[-10%] left-[-10%] w-[50%] h-[50%] bg-indigo-100/50 blur-[120px] rounded-full animate-pulse" />
        <div className="absolute bottom-[-10%] right-[-10%] w-[50%] h-[50%] bg-slate-200/50 blur-[120px] rounded-full animate-pulse delay-700" />
      </div>

      <nav className="container mx-auto px-6 py-8 flex items-center justify-between relative z-10">
        <div className="flex items-center gap-2">
           <div className="w-10 h-10 bg-indigo-600 rounded-xl flex items-center justify-center">
             <div className="w-5 h-5 bg-white rounded-full"></div>
           </div>
           <span className="text-2xl font-bold tracking-tight text-slate-900">Gilang Finance</span>
        </div>
        <div className="hidden md:flex items-center gap-8 text-sm font-medium">
          <a href="#" className="text-slate-500 hover:text-slate-900 transition-colors">Fitur</a>
          <a href="#" className="text-slate-500 hover:text-slate-900 transition-colors">Keamanan</a>
          <a href="#" className="text-slate-500 hover:text-slate-900 transition-colors">Harga</a>
          <Button variant="ghost" className="text-slate-500 hover:text-slate-900" onClick={loginWithGoogle}>Masuk</Button>
          <Button className="bg-indigo-600 text-white hover:bg-indigo-700 rounded-xl px-6 shadow-lg shadow-indigo-100" onClick={loginWithGoogle}>Mulai Sekarang</Button>
        </div>
      </nav>

      <main className="relative z-10">
        {/* Hero Section */}
        <section className="container mx-auto px-6 pt-20 pb-32 text-center">
          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-indigo-50 border border-indigo-100 mb-8"
          >
            <Badge className="bg-indigo-600 text-white border-none py-0.5 px-2">Baru</Badge>
            <span className="text-sm font-semibold text-indigo-700">Pelatih Keuangan AI Telah Tersedia</span>
            <ChevronRight className="w-4 h-4 text-indigo-400" />
          </motion.div>

          <motion.h1 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="text-6xl md:text-8xl font-bold tracking-tight text-slate-900 leading-none mb-8"
          >
            Kelola uangmu, <br />
            <span className="text-indigo-600">kuasai</span> dengan AI.
          </motion.h1>

          <motion.p 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1 }}
            className="max-w-2xl mx-auto text-xl text-slate-500 mb-12 font-medium"
          >
            Gilang Finance adalah manajer keuangan generasi masa depan. Hubungkan bank Anda, 
            pantau pengeluaran tanpa usaha, dan dapatkan wawasan berbasis AI untuk mencapai target Anda lebih cepat.
          </motion.p>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2 }}
            className="flex flex-col sm:flex-row items-center justify-center gap-4"
          >
            <Button size="lg" className="bg-indigo-600 text-white hover:bg-indigo-700 rounded-2xl px-12 py-7 text-lg font-bold shadow-xl shadow-indigo-200 h-auto" onClick={loginWithGoogle}>
              Mulai Gratis <ArrowRight className="ml-2 w-6 h-6" />
            </Button>
            <Button size="lg" variant="outline" className="rounded-2xl px-12 py-7 text-lg font-bold h-auto bg-white border-slate-200 text-slate-900 shadow-sm">
              Tonton Demo
            </Button>
          </motion.div>
        </section>

        {/* Dashboard Preview */}
        <section className="container mx-auto px-6 pb-32">
          <motion.div
            initial={{ opacity: 0, y: 40 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="relative p-2 rounded-[32px] bg-white border border-slate-200 shadow-2xl overflow-hidden"
          >
            <img 
              src="https://images.unsplash.com/photo-1611974717535-73f443a0b8ee?auto=format&fit=crop&q=80&w=2070" 
              alt="Dashboard Preview" 
              className="rounded-[24px] opacity-90 transition-all duration-700"
            />
            <div className="absolute inset-0 flex items-center justify-center bg-slate-900/10 backdrop-blur-[2px]">
               <div className="bg-white/80 backdrop-blur-md p-8 rounded-3xl border border-white/50 text-center space-y-4 max-w-sm shadow-2xl">
                  <PieChart className="w-12 h-12 text-indigo-600 mx-auto" />
                  <h3 className="text-2xl font-bold text-slate-900">Analisis Intuitif</h3>
                  <p className="text-slate-500 font-medium">Visualisasi indah yang membantu Anda memahami ke mana setiap rupiah pergi.</p>
               </div>
            </div>
          </motion.div>
        </section>

        {/* Features */}
        <section className="container mx-auto px-6 py-32 border-t border-slate-200">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-12 text-center">
            {features.map((f, i) => (
              <div key={i} className="space-y-4">
                <div className="w-16 h-16 bg-white border border-slate-100 shadow-sm rounded-3xl flex items-center justify-center mx-auto transition-transform hover:scale-110">
                  <f.icon className="w-8 h-8 text-indigo-600" />
                </div>
                <h3 className="text-xl font-bold text-slate-900">{f.title}</h3>
                <p className="text-slate-500 font-medium leading-relaxed">{f.desc}</p>
              </div>
            ))}
          </div>
        </section>

        {/* Call to Action */}
        <section className="container mx-auto px-6 py-32">
           <div className="bg-slate-900 p-16 rounded-[48px] text-center space-y-8 relative overflow-hidden text-white">
              <div className="absolute top-0 right-0 w-64 h-64 bg-indigo-500/20 blur-[100px] rounded-full" />
              <h2 className="text-4xl md:text-6xl font-bold tracking-tight">Siap mengubah masa depan <br /> finansial Anda?</h2>
              <p className="text-xl text-slate-400 max-w-xl mx-auto font-medium">Bergabunglah dengan 10.000+ orang yang mengelola uang mereka lebih cerdas dengan Gilang Finance.</p>
              <Button size="lg" className="bg-white text-slate-900 hover:bg-slate-100 rounded-2xl px-12 py-7 text-xl font-bold h-auto shadow-xl" onClick={loginWithGoogle}>
                Mulai Sekarang
              </Button>
           </div>
        </section>
      </main>

      <footer className="container mx-auto px-6 py-12 border-t border-slate-200 flex flex-col md:flex-row items-center justify-between gap-8 text-sm text-slate-400 font-medium">
        <div className="flex items-center gap-2">
           <div className="w-6 h-6 bg-indigo-600 rounded flex items-center justify-center">
             <div className="w-3 h-3 bg-white rounded-full"></div>
           </div>
           <span className="font-bold text-slate-900">Gilang Finance</span>
        </div>
        <div className="flex gap-8">
          <a href="#" className="hover:text-slate-900 transition-colors">Privasi</a>
          <a href="#" className="hover:text-slate-900 transition-colors">Ketentuan</a>
          <a href="#" className="hover:text-slate-900 transition-colors">Bantuan</a>
          <a href="#" className="hover:text-slate-900 transition-colors">Twitter</a>
        </div>
        <p>© 2026 Gilang Finance. Hak cipta dilindungi undang-undang.</p>
      </footer>
    </div>
  );
};
