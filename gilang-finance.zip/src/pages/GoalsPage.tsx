import React from 'react';
import { Card } from '../components/ui/card';

export const GoalsPage = () => (
  <div className="p-8 space-y-8 animate-in fade-in duration-700">
    <header>
      <h1 className="text-2xl font-bold tracking-tight text-slate-900">Target Menabung</h1>
      <p className="text-slate-500 text-sm">Bermimpi besar, menabung sedikit demi sedikit, capai lebih cepat.</p>
    </header>
    <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
       <Card className="artha-card p-8 relative overflow-hidden bg-slate-900 text-white">
          <div className="relative z-10">
             <h3 className="text-2xl font-bold mb-2">Tesla Model 3 Baru</h3>
             <p className="text-slate-400 mb-8">Target: Rp 1.500.000.000</p>
             <div className="space-y-4">
                <div className="flex justify-between text-sm font-bold">
                   <span>Progres</span>
                   <span className="text-emerald-400">Rp 420.000.000 terkumpul (28%)</span>
                </div>
                <div className="w-full bg-white/10 h-3 rounded-full overflow-hidden">
                   <div className="h-full bg-emerald-400" style={{ width: '28%' }} />
                </div>
             </div>
          </div>
          <div className="absolute top-0 right-0 w-32 h-32 bg-emerald-400/20 blur-3xl" />
       </Card>
    </div>
  </div>
);
