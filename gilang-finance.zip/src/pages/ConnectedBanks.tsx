import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '../components/ui/card';
import { Button } from '../components/ui/button';
import { Badge } from '../components/ui/badge';
import { 
  Plus, 
  CreditCard, 
  ShieldCheck, 
  RefreshCw, 
  CheckCircle2, 
  AlertCircle 
} from 'lucide-react';
import { cn } from '../lib/utils';

const MOCK_BANKS = [
  { id: '1', name: 'BCA (Bank Central Asia)', type: 'Tabungan Utama', status: 'connected', balance: 'Rp 12.450.000', lastSync: '2 jam lalu', color: 'bg-blue-800' },
  { id: '2', name: 'DANA Digital Wallet', type: 'E-Wallet', status: 'connected', balance: 'Rp 2.200.500', lastSync: 'Hari ini', color: 'bg-sky-500' },
  { id: '3', name: 'Bank Jago', type: 'Kantong Utama', status: 'connected', balance: 'Rp 8.750.000', lastSync: 'Baru saja', color: 'bg-orange-400' },
];

export const ConnectedBanks = () => {
  return (
    <div className="p-8 space-y-8 animate-in fade-in duration-700">
      <header className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold tracking-tight text-slate-900">Akun Terhubung</h1>
          <p className="text-slate-500 text-sm">Kelola koneksi bank Anda dengan aman serta real-time.</p>
        </div>
        <Button className="rounded-xl bg-indigo-600 text-white hover:bg-indigo-700 shadow-lg shadow-indigo-100 px-6">
          <Plus className="mr-2 w-5 h-5" /> Hubungkan Bank Baru
        </Button>
      </header>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {MOCK_BANKS.map((bank) => (
          <Card key={bank.id} className="artha-card group overflow-hidden">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <div className={cn("w-10 h-10 rounded-xl flex items-center justify-center text-white", bank.color)}>
                 <CreditCard className="w-5 h-5" />
              </div>
              <Badge variant="outline" className={cn(
                "rounded-full px-3",
                bank.status === 'connected' ? "bg-emerald-50 text-emerald-600 border-emerald-100" : "bg-rose-50 text-rose-600 border-rose-100"
              )}>
                {bank.status === 'connected' ? <CheckCircle2 className="w-3 h-3 mr-1" /> : <AlertCircle className="w-3 h-3 mr-1" />}
                {bank.status === 'connected' ? 'Terhubung' : 'Gagal Menghubungkan'}
              </Badge>
            </CardHeader>
            <CardContent className="pt-4">
              <div className="space-y-1">
                <h3 className="font-bold text-lg text-slate-900">{bank.name}</h3>
                <p className="text-xs text-slate-400 font-medium uppercase tracking-wider">{bank.type}</p>
              </div>
              <div className="mt-6 flex justify-between items-end">
                <div>
                  <p className="text-[10px] text-slate-400 font-bold uppercase">Saldo</p>
                  <p className="text-xl font-bold text-slate-900">{bank.balance}</p>
                </div>
                <Button size="icon" variant="ghost" className="rounded-xl text-slate-400 hover:text-indigo-600">
                  <RefreshCw className="w-4 h-4" />
                </Button>
              </div>
              <div className="mt-4 pt-4 border-t border-slate-50 flex items-center justify-between text-xs text-slate-400">
                <span>Sinkronisasi terakhir: {bank.lastSync}</span>
                <span className="text-indigo-600 font-bold cursor-pointer hover:underline">Link ulang</span>
              </div>
            </CardContent>
          </Card>
        ))}

        <button className="h-full min-h-[220px] rounded-3xl border-2 border-dashed border-slate-200 hover:border-indigo-300 hover:bg-slate-50 transition-all flex flex-col items-center justify-center space-y-4 group">
          <div className="w-12 h-12 rounded-2xl bg-slate-100 text-slate-400 group-hover:bg-indigo-100 group-hover:text-indigo-600 flex items-center justify-center transition-colors">
            <Plus className="w-6 h-6" />
          </div>
          <div className="text-center px-4">
            <p className="font-bold text-slate-900">Tambah Akun</p>
            <p className="text-xs text-slate-500">Mendukung 12.000+ institusi di seluruh dunia</p>
          </div>
        </button>
      </div>

      <Card className="bg-slate-900 rounded-[32px] p-8 text-white relative overflow-hidden">
        <div className="relative z-10 flex flex-col md:flex-row items-center gap-8">
          <div className="w-16 h-16 bg-white/10 rounded-3xl flex items-center justify-center">
            <ShieldCheck className="w-8 h-8 text-indigo-400" />
          </div>
          <div className="flex-1 text-center md:text-left">
            <h3 className="text-2xl font-bold mb-2">Privasi & Keamanan Utama</h3>
            <p className="text-slate-400 max-w-xl">
              Gilang Finance menggunakan enkripsi AES-256 standar bank untuk melindungi data Anda. Kami tidak pernah menyimpan kredensial login Anda. 
              Koneksi baca-saja kami memastikan uang Anda tetap aman di tempatnya.
            </p>
          </div>
          <Button variant="outline" className="rounded-xl bg-white/5 border-white/10 text-white hover:bg-white/10">
            Tinjauan Keamanan
          </Button>
        </div>
        <div className="absolute top-0 right-0 w-64 h-64 bg-indigo-500/10 blur-[100px] rounded-full" />
      </Card>
    </div>
  );
};

