import React, { useEffect, useState } from 'react';
import { 
  Plus, 
  TrendingUp, 
  TrendingDown, 
  DollarSign, 
  Activity,
  Calendar,
  AlertCircle,
  ChevronRight,
  Sparkles,
  Bot,
  Trash2,
  Settings
} from 'lucide-react';
import { motion } from 'motion/react';
import { 
  AreaChart, 
  Area, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer,
  BarChart,
  Bar,
  Cell
} from 'recharts';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { useAuthStore } from '@/store/useAuthStore';
import { useFinanceStore } from '@/store/useFinanceStore';
import { getFinancialAdvice } from '@/services/gemini';
import { Skeleton } from '@/components/ui/skeleton';
import { Badge } from '@/components/ui/badge';
import { cn } from '@/lib/utils';

import { 
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
  DialogFooter,
} from '@/components/ui/dialog';
import { Label } from '@/components/ui/label';
import { Input } from '@/components/ui/input';
import { 
  Select, 
  SelectContent, 
  SelectItem, 
  SelectTrigger, 
  SelectValue 
} from '@/components/ui/select';
import { toast } from 'sonner';

const data = [
  { name: 'Mon', income: 4000, expense: 2400 },
  { name: 'Tue', income: 3000, expense: 1398 },
  { name: 'Wed', income: 2000, expense: 9800 },
  { name: 'Thu', income: 2780, expense: 3908 },
  { name: 'Fri', income: 1890, expense: 4800 },
  { name: 'Sat', income: 2390, expense: 3800 },
  { name: 'Sun', income: 3490, expense: 4300 },
];

const categoryData = [
  { name: 'Food', value: 400, color: '#00FF00' },
  { name: 'Transport', value: 300, color: '#A855F7' },
  { name: 'Entertainment', value: 300, color: '#3B82F6' },
  { name: 'Bills', value: 200, color: '#F43F5E' },
];

export const Dashboard = ({ setActiveTab }: { setActiveTab?: (tab: string) => void }) => {
  const { profile } = useAuthStore();
  const { 
    transactions, 
    fetchTransactions, 
    categories, 
    fetchCategories, 
    addCategory, 
    deleteCategory,
    addTransaction 
  } = useFinanceStore();
  const [aiInsight, setAiInsight] = useState<any>(null);
  const [isCategoryModalOpen, setIsCategoryModalOpen] = useState(false);
  const [newCategoryName, setNewCategoryName] = useState('');
  const [newCategoryColor, setNewCategoryColor] = useState('#4f46e5');

  useEffect(() => {
    if (profile?.uid) {
      const unsubTx = fetchTransactions(profile.uid);
      const unsubCat = fetchCategories(profile.uid);
      return () => {
        unsubTx();
        unsubCat();
      };
    }
  }, [profile?.uid]);

  const handleAddCategory = async () => {
    if (!profile || !newCategoryName.trim()) return;
    try {
      await addCategory(profile.uid, newCategoryName.trim(), newCategoryColor);
      setNewCategoryName('');
      toast.success('Kategori berhasil ditambahkan');
    } catch (error) {
      toast.error('Gagal menambahkan kategori');
    }
  };

  useEffect(() => {
    const fetchInsight = async () => {
      if (transactions.length > 0 && !aiInsight) {
        const insight = await getFinancialAdvice(transactions, profile);
        setAiInsight(insight);
      }
    };
    fetchInsight();
  }, [transactions]);

  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [newTx, setNewTx] = useState({
    amount: '',
    description: '',
    category: 'Food',
    type: 'expense' as 'income' | 'expense',
    date: new Date().toISOString().split('T')[0]
  });

  const handleAddTransaction = async () => {
    if (!profile) return;
    try {
      await addTransaction(profile.uid, {
        ...newTx,
        amount: parseFloat(newTx.amount),
        currency: 'IDR',
        bankAccountId: 'manual',
        merchantName: newTx.description,
        manual: true
      });
      setIsAddModalOpen(false);
      setNewTx({
        amount: '',
        description: '',
        category: 'Food',
        type: 'expense',
        date: new Date().toISOString().split('T')[0]
      });
      toast.success('Transaksi berhasil ditambahkan');
    } catch (error) {
      toast.error('Gagal menambahkan transaksi');
    }
  };

  const stats = [
    { label: 'Total Saldo', value: 'Rp 24.560.000', icon: DollarSign, trend: '+12.5%', color: 'text-indigo-600', isPrimary: false },
    { label: 'Pemasukan Bulan Ini', value: 'Rp 8.230.120', icon: TrendingUp, trend: '+5.2%', color: 'text-emerald-600', isPrimary: false },
    { label: 'Pengeluaran Bulan Ini', value: 'Rp 3.420.500', icon: TrendingDown, trend: '-2.1%', color: 'text-rose-600', isPrimary: false },
    { label: 'Kesehatan Finansial', value: '82/100', icon: Activity, trend: 'Optimal', color: 'text-white', isPrimary: true },
  ];

  return (
    <div className="p-8 space-y-8 artha-gradient min-h-screen">
      <header className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold tracking-tight text-slate-900">Ringkasan Finansial</h1>
          <p className="text-slate-500 text-sm">Selamat datang, {profile?.displayName || 'Sahabat Gilang'}. Keuangan Anda dalam kondisi sehat.</p>
        </div>
        <div className="flex gap-3">
          <Button variant="outline" className="rounded-xl bg-white border-slate-200 text-slate-900 hover:bg-slate-50">
            <Calendar className="mr-2 w-4 h-4 text-slate-400" /> Ekspor Laporan
          </Button>
          
          <Dialog open={isAddModalOpen} onOpenChange={setIsAddModalOpen}>
            <DialogTrigger render={
              <Button className="rounded-xl bg-indigo-600 text-white hover:bg-indigo-700 shadow-lg shadow-indigo-100">
                <Plus className="mr-2 w-5 h-5" /> Tambah Transaksi
              </Button>
            } />
            <DialogContent className="sm:max-w-[425px] rounded-3xl">
              <DialogHeader>
                <DialogTitle>Tambah Transaksi</DialogTitle>
              </DialogHeader>
              <div className="grid gap-4 py-4">
                <div className="space-y-2">
                  <Label htmlFor="type">Tipe</Label>
                  <Select 
                    value={newTx.type} 
                    onValueChange={(v: any) => setNewTx({...newTx, type: v})}
                  >
                    <SelectTrigger className="rounded-xl">
                      <SelectValue placeholder="Pilih tipe" />
                    </SelectTrigger>
                    <SelectContent className="rounded-xl">
                      <SelectItem value="expense">Pengeluaran</SelectItem>
                      <SelectItem value="income">Pemasukan</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="amount">Jumlah (Rp)</Label>
                  <Input 
                    id="amount" 
                    type="number" 
                    placeholder="0" 
                    className="rounded-xl"
                    value={newTx.amount}
                    onChange={(e) => setNewTx({...newTx, amount: e.target.value})}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="description">Deskripsi</Label>
                  <Input 
                    id="description" 
                    placeholder="Contoh: Kopi Starbucks" 
                    className="rounded-xl"
                    value={newTx.description}
                    onChange={(e) => setNewTx({...newTx, description: e.target.value})}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="category">Kategori</Label>
                  <Select 
                    value={newTx.category} 
                    onValueChange={(v) => setNewTx({...newTx, category: v})}
                  >
                    <SelectTrigger className="rounded-xl">
                      <SelectValue placeholder="Pilih kategori" />
                    </SelectTrigger>
                    <SelectContent className="rounded-xl">
                      {categories.length > 0 ? (
                        categories.map((cat) => (
                          <SelectItem key={cat.id} value={cat.name}>{cat.name}</SelectItem>
                        ))
                      ) : (
                        <>
                          <SelectItem value="Food">Makan & Minum</SelectItem>
                          <SelectItem value="Transportation">Transportasi</SelectItem>
                          <SelectItem value="Shopping">Belanja</SelectItem>
                          <SelectItem value="Entertainment">Hiburan</SelectItem>
                          <SelectItem value="Utilities">Tagihan</SelectItem>
                          <SelectItem value="Investment">Investasi</SelectItem>
                          <SelectItem value="Salary">Gaji</SelectItem>
                        </>
                      )}
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="date">Tanggal</Label>
                  <Input 
                    id="date" 
                    type="date" 
                    className="rounded-xl"
                    value={newTx.date}
                    onChange={(e) => setNewTx({...newTx, date: e.target.value})}
                  />
                </div>
              </div>
              <DialogFooter>
                <Button 
                  onClick={handleAddTransaction}
                  className="w-full bg-indigo-600 text-white rounded-xl"
                >
                  Simpan Transaksi
                </Button>
              </DialogFooter>
            </DialogContent>
          </Dialog>

          <Dialog open={isCategoryModalOpen} onOpenChange={setIsCategoryModalOpen}>
            <DialogTrigger render={
              <Button variant="outline" className="rounded-xl bg-white border-slate-200 text-slate-900 hover:bg-slate-50">
                <Settings className="mr-2 w-4 h-4 text-slate-400" /> Kelola Kategori
              </Button>
            } />
            <DialogContent className="sm:max-w-[425px] rounded-3xl">
              <DialogHeader>
                <DialogTitle>Kelola Kategori</DialogTitle>
              </DialogHeader>
              <div className="space-y-6 py-4">
                <div className="space-y-3">
                  <Label>Tambah Kategori Baru</Label>
                  <div className="flex gap-2">
                    <Input 
                      placeholder="Nama kategori..." 
                      className="rounded-xl"
                      value={newCategoryName}
                      onChange={(e) => setNewCategoryName(e.target.value)}
                    />
                    <Input 
                      type="color" 
                      className="w-12 h-10 p-1 rounded-xl cursor-pointer"
                      value={newCategoryColor}
                      onChange={(e) => setNewCategoryColor(e.target.value)}
                    />
                    <Button onClick={handleAddCategory} className="rounded-xl bg-indigo-600">
                      <Plus className="w-5 h-5" />
                    </Button>
                  </div>
                </div>

                <div className="space-y-3">
                  <Label>Daftar Kategori</Label>
                  <div className="max-h-[300px] overflow-y-auto space-y-2 pr-2">
                    {categories.map((cat) => (
                      <div key={cat.id} className="flex items-center justify-between p-3 bg-slate-50 rounded-xl border border-slate-100 group">
                        <div className="flex items-center gap-3">
                          <div className="w-3 h-3 rounded-full" style={{ backgroundColor: cat.color }} />
                          <span className="text-sm font-medium text-slate-700">{cat.name}</span>
                        </div>
                        <button 
                          onClick={() => deleteCategory(cat.id)}
                          className="text-slate-400 hover:text-rose-500 opacity-0 group-hover:opacity-100 transition-opacity"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    ))}
                    {categories.length === 0 && (
                      <p className="text-center text-slate-400 text-xs py-4 italic">Belum ada kategori kustom.</p>
                    )}
                  </div>
                </div>
              </div>
            </DialogContent>
          </Dialog>
        </div>
      </header>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {stats.map((stat, i) => (
          <motion.div
            key={stat.label}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: i * 0.1 }}
          >
            <Card className={cn(
              "overflow-hidden group border-none shadow-sm",
              stat.isPrimary ? "bg-indigo-600 text-white shadow-indigo-100" : "bg-white text-slate-900"
            )}>
              <CardHeader className="flex flex-row items-center justify-between pb-2 space-y-0 text-slate-400">
                <CardTitle className={cn("text-xs font-semibold uppercase tracking-wider", stat.isPrimary ? "text-indigo-100" : "text-slate-400")}>
                  {stat.label}
                </CardTitle>
                <div className={cn("p-2 rounded-lg transition-transform group-hover:scale-110", stat.isPrimary ? "bg-white/10" : "bg-slate-50")}>
                  <stat.icon className={cn("w-4 h-4", stat.color)} />
                </div>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{stat.value}</div>
                <p className={cn("text-xs mt-1 font-medium", stat.isPrimary ? "text-indigo-200" : "text-slate-500")}>
                   {stat.trend} dibandingkan bulan lalu
                </p>
              </CardContent>
            </Card>
          </motion.div>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <Card className="lg:col-span-2 artha-card">
          <CardHeader className="flex flex-row items-center justify-between">
            <CardTitle className="text-slate-900">Analisis Arus Kas</CardTitle>
            <div className="flex gap-2">
              <Badge variant="secondary" className="bg-slate-100 text-slate-900 hover:bg-slate-200 cursor-pointer">Mingguan</Badge>
              <Badge className="bg-slate-900 text-white hover:bg-slate-800 cursor-pointer">Bulanan</Badge>
            </div>
          </CardHeader>
          <CardContent>
            <div className="w-full h-[350px]" style={{ minHeight: '350px' }}>
              <ResponsiveContainer width="100%" height="100%">
                <AreaChart data={data}>
                <defs>
                  <linearGradient id="colorIncome" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#4f46e5" stopOpacity={0.1}/>
                    <stop offset="95%" stopColor="#4f46e5" stopOpacity={0}/>
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#e2e8f0" />
                <XAxis dataKey="name" axisLine={false} tickLine={false} tick={{ fill: '#64748b', fontSize: 12 }} />
                <YAxis axisLine={false} tickLine={false} tick={{ fill: '#64748b', fontSize: 12 }} />
                <Tooltip 
                  contentStyle={{ backgroundColor: '#fff', border: '1px solid #e2e8f0', borderRadius: '12px', boxShadow: '0 4px 6px -1px rgb(0 0 0 / 0.1)' }}
                  formatter={(value: any) => [`Rp ${value.toLocaleString()}`, '']}
                />
                <Area type="monotone" dataKey="income" stroke="#4f46e5" strokeWidth={3} fillOpacity={1} fill="url(#colorIncome)" />
                <Area type="monotone" dataKey="expense" stroke="#cbd5e1" strokeWidth={2} fillOpacity={0} />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </CardContent>
        </Card>

        <div className="space-y-6">
          <Card className="bg-slate-900 rounded-3xl border-none p-2 text-white overflow-hidden relative min-h-[250px] flex flex-col justify-between">
            <div className="absolute top-0 right-0 p-4">
              <div className="px-2 py-1 bg-white/10 rounded-lg text-[10px] font-bold">BETA</div>
            </div>
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-indigo-400 text-xs font-bold uppercase tracking-widest">
                <Bot className="w-4 h-4" /> AI Smart Coach
              </CardTitle>
            </CardHeader>
            <CardContent className="flex-1">
              {aiInsight ? (
                <div className="space-y-4">
                  <p className="text-lg leading-snug">
                    "{aiInsight.prediction}"
                  </p>
                  <div className="space-y-3">
                    {aiInsight.tips.slice(0, 1).map((tip: any, i: number) => (
                      <div key={i} className="p-3 bg-white/5 rounded-xl border border-white/10">
                        <p className="text-xs font-semibold text-indigo-400 mb-1">{tip.title}</p>
                        <p className="text-xs text-slate-300 leading-relaxed">{tip.message}</p>
                      </div>
                    ))}
                  </div>
                </div>
              ) : (
                <div className="space-y-3">
                  <Skeleton className="h-12 w-full rounded-xl bg-white/5" />
                  <Skeleton className="h-20 w-full rounded-xl bg-white/5" />
                </div>
              )}
            </CardContent>
            <div className="p-4 flex gap-2">
              <Button size="sm" className="flex-1 bg-white text-slate-900 hover:bg-slate-100 font-bold rounded-xl text-xs">Terapkan Tips</Button>
              <Button size="sm" variant="ghost" className="flex-1 text-white hover:bg-white/10 font-bold rounded-xl text-xs">Abaikan</Button>
            </div>
          </Card>

          <Card className="artha-card">
            <CardHeader>
              <CardTitle className="text-sm flex items-center justify-between text-slate-900 font-bold">
                Tantangan Harian
                <Badge variant="outline" className="text-indigo-600 border-indigo-100 bg-indigo-50">PRO</Badge>
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
               <div className="space-y-2">
                 <div className="flex justify-between text-xs font-medium">
                    <span className="text-slate-500">7 Hari Tanpa Belanja</span>
                    <span className="text-slate-900 font-bold">5/7 hari</span>
                 </div>
                 <div className="h-1.5 w-full bg-slate-100 rounded-full overflow-hidden">
                    <div className="h-full bg-indigo-600" style={{ width: '70%' }} />
                 </div>
               </div>
               <div className="p-3 rounded-xl bg-slate-50 border border-slate-100">
                 <p className="text-[10px] font-bold text-slate-400 uppercase tracking-wider mb-2">Pantau Mood</p>
                 <div className="flex justify-between">
                    {['😊', '😔', '😤', '🥳', '🤔'].map((emoji, i) => (
                      <button key={i} className="p-1 hover:bg-white rounded-lg transition-colors grayscale hover:grayscale-0">{emoji}</button>
                    ))}
                 </div>
               </div>
            </CardContent>
          </Card>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        <Card className="artha-card">
          <CardHeader className="flex flex-row items-center justify-between">
            <CardTitle className="text-slate-900">Transaksi Terakhir</CardTitle>
            <Button 
              variant="link" 
              className="text-indigo-600 text-xs font-bold p-0 h-auto"
              onClick={() => setActiveTab?.('transactions')}
            >
              Lihat Semua
            </Button>
          </CardHeader>
          <CardContent className="p-0">
             <div className="divide-y divide-slate-50">
                {transactions.slice(0, 4).map((tx) => (
                  <div key={tx.id} className="flex items-center justify-between p-4 hover:bg-slate-50 transition-colors cursor-pointer group">
                    <div className="flex items-center gap-3">
                      <div className={cn(
                        "w-10 h-10 rounded-xl flex items-center justify-center font-bold text-xs group-hover:bg-white transition-colors",
                        tx.type === 'income' ? "bg-emerald-50 text-emerald-600" : "bg-slate-50 text-slate-400 border border-slate-100"
                      )}>
                        {tx.merchantName?.substring(0, 2).toUpperCase() || 'TX'}
                      </div>
                      <div>
                        <p className="text-sm font-bold text-slate-900">{tx.description}</p>
                        <p className="text-xs text-slate-400">{tx.category} • {new Date(tx.date).toLocaleDateString('id-ID')}</p>
                      </div>
                    </div>
                    <div className="text-right">
                      <p className={cn(
                        "text-sm font-bold",
                        tx.type === 'income' ? "text-emerald-600" : "text-slate-900"
                      )}>
                        {tx.type === 'income' ? '+' : '-'}Rp {Math.abs(tx.amount).toLocaleString('id-ID')}
                      </p>
                    </div>
                  </div>
                ))}
                {transactions.length === 0 && (
                  <div className="p-8 text-center text-slate-400 text-sm">
                    Belum ada transaksi. Klik "+ Tambah Transaksi" untuk memulai.
                  </div>
                )}
             </div>
          </CardContent>
        </Card>

        <Card className="artha-card">
          <CardHeader>
            <CardTitle className="text-slate-900 text-md">Tagihan Mendatang</CardTitle>
          </CardHeader>
          <CardContent>
             <div className="space-y-3">
                {[
                  { name: 'Langganan Netflix', amount: 'Rp 186.000', date: '12 Mei', type: 'Subscription' },
                  { name: 'Bayar Kos/Kontrakan', amount: 'Rp 2.500.000', date: '15 Mei', type: 'Rent' },
                  { name: 'Tagihan Listrik', amount: 'Rp 450.000', date: '20 Mei', type: 'Utility' },
                ].map((bill, i) => (
                  <div key={i} className="flex items-center justify-between p-4 bg-slate-50 rounded-2xl border border-white hover:border-slate-200 transition-all">
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 rounded-xl bg-white shadow-sm flex items-center justify-center">
                        <Calendar className="w-5 h-5 text-indigo-500" />
                      </div>
                      <div>
                        <p className="text-sm font-bold text-slate-900">{bill.name}</p>
                        <p className="text-xs text-slate-400">{bill.date}</p>
                      </div>
                    </div>
                    <p className="text-sm font-bold text-slate-900">{bill.amount}</p>
                  </div>
                ))}
             </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};
