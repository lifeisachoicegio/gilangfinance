import React from 'react';
import { Card } from '../components/ui/card';
import { Badge } from '../components/ui/badge';
import { Utensils, Bus, Film, ShoppingBag } from 'lucide-react';
import { cn } from '../lib/utils';

export const BudgetPage = () => (
  <div className="p-8 space-y-8 animate-in fade-in duration-700">
    <header>
      <h1 className="text-2xl font-bold tracking-tight text-slate-900">Perencana Anggaran</h1>
      <p className="text-slate-500 text-sm">Tetapkan dan pantau batasan untuk setiap kategori pengeluaran.</p>
    </header>
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
       {[
         { category: 'Makan & Minum', spent: 450000, budget: 600000, color: 'bg-orange-500', icon: Utensils },
         { category: 'Transportasi', spent: 120000, budget: 150000, color: 'bg-blue-500', icon: Bus },
         { category: 'Hiburan', spent: 280000, budget: 200000, color: 'bg-purple-500', icon: Film },
         { category: 'Belanja', spent: 850000, budget: 1000000, color: 'bg-emerald-500', icon: ShoppingBag },
       ].map((b, i) => (
         <Card key={i} className="artha-card p-6">
            <div className="flex justify-between items-center mb-4">
               <div className="flex items-center gap-3">
                  <div className={cn("p-2 rounded-xl group-hover:scale-110 transition-transform", b.color, "bg-opacity-10")}>
                    <b.icon className={cn("w-5 h-5", b.color.replace('bg-', 'text-'))} />
                  </div>
                  <h3 className="font-bold text-slate-900">{b.category}</h3>
               </div>
               <Badge className={cn("bg-opacity-10 py-0 px-2 border-none", b.spent > b.budget ? "bg-rose-500 text-rose-600" : "bg-emerald-500 text-emerald-600")}>
                  {b.spent > b.budget ? 'Over Budget' : 'On Track'}
               </Badge>
            </div>
            <div className="space-y-4">
               <div className="flex justify-between text-xs">
                  <span className="text-slate-400">Terpakai: Rp {b.spent.toLocaleString('id-ID')}</span>
                  <span className="text-slate-900 font-bold">Anggaran: Rp {b.budget.toLocaleString('id-ID')}</span>
               </div>
               <div className="w-full bg-slate-100 h-2 rounded-full overflow-hidden">
                  <div className={cn("h-full", b.color)} style={{ width: `${Math.min((b.spent/b.budget)*100, 100)}%` }} />
               </div>
            </div>
         </Card>
       ))}
    </div>
  </div>
);
