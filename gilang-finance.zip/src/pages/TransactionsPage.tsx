import React, { useState } from 'react';
import { useAuthStore } from '../store/useAuthStore';
import { useFinanceStore } from '../store/useFinanceStore';
import { Card, CardContent, CardHeader, CardTitle } from '../components/ui/card';
import { Input } from '../components/ui/input';
import { Button } from '../components/ui/button';
import { Badge } from '../components/ui/badge';
import { 
  Search, 
  Filter, 
  Download, 
  ArrowUpRight, 
  ArrowDownLeft,
  Calendar,
  MoreHorizontal
} from 'lucide-react';
import { cn } from '../lib/utils';

export const TransactionsPage = () => {
  const { profile } = useAuthStore();
  const { transactions } = useFinanceStore();
  const [searchTerm, setSearchTerm] = useState('');

  const filteredTransactions = transactions.filter(tx => 
    tx.description.toLowerCase().includes(searchTerm.toLowerCase()) ||
    tx.category.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="p-8 space-y-8 animate-in fade-in duration-700">
      <header className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold tracking-tight text-slate-900">Daftar Transaksi</h1>
          <p className="text-slate-500 text-sm">Pantau dan kelola arus kas Anda.</p>
        </div>
        <div className="flex gap-3">
          <Button variant="outline" className="rounded-xl bg-white border-slate-200">
            <Download className="mr-2 w-4 h-4 text-slate-400" /> Ekspor CSV
          </Button>
          <Button className="rounded-xl bg-indigo-600 text-white hover:bg-indigo-700 shadow-lg shadow-indigo-100">
            Sinkronisasi Akun
          </Button>
        </div>
      </header>

      <Card className="artha-card">
        <CardHeader className="pb-0">
          <div className="flex items-center justify-between gap-4">
            <div className="relative flex-1 max-w-sm">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
              <Input 
                placeholder="Cari transaksi..." 
                className="pl-10 rounded-xl bg-slate-50 border-slate-100"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
              />
            </div>
            <div className="flex gap-2">
              <Button variant="outline" size="sm" className="rounded-lg border-slate-100">
                <Filter className="mr-2 w-3 h-3" /> Filter
              </Button>
              <Button variant="outline" size="sm" className="rounded-lg border-slate-100">
                <Calendar className="mr-2 w-3 h-3" /> Rentang Tanggal
              </Button>
            </div>
          </div>
        </CardHeader>
        <CardContent className="pt-6">
          <div className="overflow-x-auto">
            <table className="w-full text-left">
              <thead>
                <tr className="text-[10px] font-bold text-slate-400 uppercase tracking-widest border-b border-slate-50">
                  <th className="pb-4 px-4 font-bold">Transaksi</th>
                  <th className="pb-4 px-4 font-bold">Kategori</th>
                  <th className="pb-4 px-4 font-bold">Tanggal</th>
                  <th className="pb-4 px-4 font-bold text-right">Jumlah</th>
                  <th className="pb-4 px-4"></th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-50">
                {filteredTransactions.map((tx) => (
                  <tr key={tx.id} className="group hover:bg-slate-50/50 transition-colors">
                    <td className="py-4 px-4">
                      <div className="flex items-center gap-3">
                        <div className={cn(
                          "w-10 h-10 rounded-xl flex items-center justify-center font-bold text-xs",
                          tx.type === 'income' ? "bg-emerald-50 text-emerald-600" : "bg-slate-50 text-slate-400 border border-slate-100"
                        )}>
                          {tx.merchantName?.substring(0, 2).toUpperCase() || 'TX'}
                        </div>
                        <div>
                          <p className="text-sm font-bold text-slate-900">{tx.description}</p>
                          <p className="text-xs text-slate-400">{tx.bankAccountId === 'manual' ? 'Input Manual' : 'Sinkron Bank'}</p>
                        </div>
                      </div>
                    </td>
                    <td className="py-4 px-4">
                      <Badge variant="secondary" className="bg-slate-50 text-slate-500 font-medium rounded-lg px-2 py-0.5 border-none">
                        {tx.category}
                      </Badge>
                    </td>
                    <td className="py-4 px-4">
                      <p className="text-sm text-slate-500">{new Date(tx.date).toLocaleDateString('id-ID')}</p>
                    </td>
                    <td className="py-4 px-4 text-right">
                      <p className={cn(
                        "text-sm font-bold",
                        tx.type === 'income' ? "text-emerald-600" : "text-slate-900"
                      )}>
                        {tx.type === 'income' ? '+' : '-'}Rp {Math.abs(tx.amount).toLocaleString('id-ID')}
                      </p>
                    </td>
                    <td className="py-4 px-4 text-right">
                      <Button variant="ghost" size="sm" className="opacity-0 group-hover:opacity-100 transition-opacity">
                        <MoreHorizontal className="w-4 h-4 text-slate-400" />
                      </Button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          {filteredTransactions.length === 0 && (
            <div className="py-12 text-center text-slate-400">
               <ArrowUpRight className="w-12 h-12 mx-auto mb-4 opacity-20" />
               <p className="font-medium">Transaksi tidak ditemukan</p>
               <p className="text-sm">Coba sesuaikan pencarian atau tambah transaksi manual.</p>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
};
